/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.services;
import com.esprit.models.Event;
import com.esprit.utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 *
 * @author maram
 */

public class ServiceEvent implements IService<Event> {
    Connection cnx = DataSource.getInstance().getCnx();
    private Statement ste;
    private PreparedStatement ps;
    private ResultSet rs;


    @Override
    public void ajouter(Event t) {
        try {
            String requete = "INSERT INTO event (nom,date_debut,date_fin) VALUES (?,?,?)";
            PreparedStatement evt = cnx.prepareStatement(requete);
            /*evt.setInt(1, t.getId());*/
            evt.setString(1, t.getNom());
            evt.setString(2, t.getDateDebut());
            evt.setString(3, t.getDateFin());
            evt.executeUpdate();
            System.out.println("evenement ajoutée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServiceEvent.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(Event t) {
        try {
            String requete = "DELETE FROM event WHERE id=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, t.getId());
            pst.executeUpdate();
            System.out.println("evenement supprimée !");

        } catch (SQLException ex) {
            Logger.getLogger(ServiceEvent.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void modifier(int id , String nom ,String date_debut,String date_fin) {
        try {
            String requete = "UPDATE event SET nom=?,date_debut=?,date_fin=? WHERE id=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(4,id);
            pst.setString(1,nom);
            pst.setString(2,date_debut);
            pst.setString(3,date_fin);
            pst.executeUpdate();
          
            System.out.println("evenement modifiée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public List<Event> afficher() {
        List<Event> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM event";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                list.add(new Event(rs.getInt(1), rs.getString(2), rs.getString("date_debut"),rs.getString("date_fin")));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return list;
    } 
     public ObservableList<Event> tricro() {
       ObservableList <Event> list = FXCollections.observableArrayList();
       String req="select * from event Order By price ASC";
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
            while(rs.next()){
               int id=rs.getInt("id");
               String nom= rs.getString("nom");
               String date_debut =rs.getString("date_debut");
               String date_fin =rs.getString("date_fin");
               Event e  = new Event( id,nom,date_debut,date_fin);
               e.setId(id);
               list.add(e);
              
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
        return list; 
     }
        
    public ObservableList<Event> tridec() {
       ObservableList <Event> list = FXCollections.observableArrayList();
       String req="select * from event Order By date_debut DESC ";
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
            while(rs.next()){
               int id=rs.getInt("id");
               String nom= rs.getString("nom");
               String date_debut =rs.getString("date_debut");
               String date_fin =rs.getString("date_fin");
   
              //list.add(new Societe(Id , nom, tel ,adresse,image));
               Event e  = new Event( id,nom,date_debut,date_fin);
               e.setId(id);
               list.add(e);
              
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
        return list; 
    }
       public ObservableList<Event> listerRecherche (String recherche) {
       ObservableList <Event> list = FXCollections.observableArrayList();
        String req = "SELECT * FROM Event WHERE nom like '%" + recherche + "%' or date_debut like'%" + recherche  + "%'or date_fin  like '%" + recherche +"%' ";
         
        try {
            ste=cnx.createStatement();
            rs=ste.executeQuery(req);
            while(rs.next()){
               int id=rs.getInt("id");
               String nom= rs.getString("nom");
               String date_debut =rs.getString("date_debut");
               String date_fin=rs.getString("date_fin");
               
               
              
                //list.add(new Societe(Id , nom, tel ,adresse,image));
                Event e  = new Event( id,nom,date_debut,date_fin);
               e.setId(id);
               list.add(e);
               
            }
            
        } catch (SQLException ex) {
            System.out.println("erreur");
        }
         
         return list;   
    }  

 
}
