/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 
package com.esprit.services;

import com.esprit.models.Event;
import com.esprit.utils.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author maram
 
public class ServiceEvent2 implements IService<Event> {

    Connection cnx = DataSource.getInstance().getCnx();

    @Override
    public void ajouter(Event t) {
        try {
            String requete = "INSERT INTO event (nom,date) VALUES ('" + t.getNom() + "','" + t.getDate() + "')";
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("event ajoutée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(Event t) {
        try {
            String requete = "DELETE FROM event WHERE id=" + t.getId();
            Statement st = cnx.createStatement();
            st.executeUpdate(requete);
            System.out.println("evenement supprimée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
   public void modifier(int id , String nom ,String date) {
        try {
            String requete = "UPDATE event SET nom=?,date=? WHERE id=?";
            PreparedStatement pst = cnx.prepareStatement(requete);
            pst.setInt(1, id);
            pst.setString(2,nom);
            pst.setString(3,date);
            pst.executeUpdate();
          
            System.out.println("evenement modifiée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public List<Event> afficher() {
        List<Event> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM event";
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                list.add(new Event(rs.getInt(1), rs.getString(2), rs.getString("date")));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return list;
    }
} */
