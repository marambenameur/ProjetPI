/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.tests;

import com.esprit.models.Event;
import com.esprit.services.ServiceEvent;


import com.esprit.models.Promo;
import com.esprit.services.ServicePromo;

/**
 *
 * @author maram
 */
public class MainProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServiceEvent ev = new ServiceEvent();
        ServicePromo pr =new ServicePromo();
       
    /*Event   e55=new Event(1,"hjjjk","156525","5556");
         ev.afficher().forEach(System.out::println);
         ev1.afficher().forEach(System.out::println);
          ev2.afficher().forEach(System.out::println);
         //ev.modifier(1,"happy hour","12/10/2020","13/10/2022");
         //ev.supprimer(e55);*/
         
     /*ev.ajouter(new Event ("happy","10/12/2202","12/12/42"));
     ev.ajouter(new Event ("happy","10/12/2202","12/12/42"));
    /* Event e= new Event (12,"happy","10/12/2202","12/12/42");
     ev.supprimer(e);*/
  System.out.println(ev.listerRecherche("10/12/2202"));
         
         
        
    }
}

   
