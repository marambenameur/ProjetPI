/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.models;

/**
 *
 * @author maram
 */
public class Promo {
     private int id;
    private int pourcentage;
    private String date_debut ;
    private String date_fin ;

    public Promo(int id, int pourcentage , String date_debut, String date_fin) {
        this.id = id;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
    }

    public Promo(String nom, String date) {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPourcentage() {
        return pourcentage;
    }

    public void setPourcentage(int pourcentage) {
        this.pourcentage =pourcentage;
    }

    public String getDateDebut() {
        return date_debut;
    }

    public void setDateDebut(String date_debut) {
        this.date_debut = date_debut;
    }
    public String getDateFin() {
        return date_fin;
    }

    public void setDateFin(String date_fin) {
        this.date_fin = date_fin;
    }

    @Override
    public String toString() {
        return "Promo{" + "id=" + id + ", pourcentage=" + pourcentage + ", date debut="+ date_debut + ",date fin=" + date_fin+ '}';
        
    }
}
