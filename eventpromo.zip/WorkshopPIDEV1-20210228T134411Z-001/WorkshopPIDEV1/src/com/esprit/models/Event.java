/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.esprit.models;

/**
 *
 * @author maram
 */
public class Event { 
    private int id;
    private String nom;
    private String date_debut ;
    private String date_fin ;

    public Event(int id, String nom, String date_debut, String date_fin) {
        this.id = id;
        this.nom = nom;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
    }
     public Event( String nom, String date_debut, String date_fin) {
        this.nom = nom;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
    }
    

    /*public Event (String nom, String date) {
        this.nom = nom;
        this.date = date;
    }*/

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDateDebut() {
        return date_debut;
    }

    public void setDateDebut(String date_debut) {
        this.date_debut = date_debut;
    }
    public String getDateFin() {
        return date_fin;
    }

    public void setDateFin(String date_fin) {
        this.date_fin = date_fin;
    }

    @Override
    public String toString() {
        return "Event{" + "id=" + id + ", nom=" + nom + ", date debut="+ date_debut + ",date fin=" + date_fin+ '}';
        
    }
}

    

