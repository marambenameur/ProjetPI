<?php

namespace App\Controller;

use MercurySeries\FlashyBundle\FlashyNotifier;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class PagesController extends AbstractController
{
    /**
     * @Route("/pages", name="pages")
     */
    public function home(FlashyNotifier $flashy)
    {  $flashy->success('just a message', 'http://your-awesome-link.com');
       return $this->redirectToRoute('pages');
    }
    public function pages()
    {
        return $this->render('pages/index.html.twig');
    }

}
